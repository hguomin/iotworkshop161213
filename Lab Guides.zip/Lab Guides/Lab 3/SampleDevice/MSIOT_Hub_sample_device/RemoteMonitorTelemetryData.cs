using System.CodeDom;

namespace MSIOT_Hub_sample_device
{
    public class RemoteMonitorTelemetryData
    {
        public string DeviceId { get; set; }
        public double Temperature { get; set; }
        public double Humidity { get; set; }
        public double? ExternalTemperature { get; set; }

        // See exercise 1.2 for adding the additional telemetry properties
        // ** Paste code snippet here **
        
    }
}