/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />
Macro.InsertText("public double OilPressure { get; set; }")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("public double Vibration { get; set; }")