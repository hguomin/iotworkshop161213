/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText(",")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("OilPressure = OilPressureSlider.Value,")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("Vibration = VibrationSlider.Value")
dte.ActiveDocument.Selection.NewLine()

