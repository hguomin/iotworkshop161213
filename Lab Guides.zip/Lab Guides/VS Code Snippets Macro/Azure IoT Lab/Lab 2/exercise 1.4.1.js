/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("deviceProps.Add(\"Device color\", \"Bright red\");")
dte.ActiveDocument.Selection.NewLine()
