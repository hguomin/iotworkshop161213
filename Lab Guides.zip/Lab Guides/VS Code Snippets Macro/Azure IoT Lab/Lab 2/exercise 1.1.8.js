/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("var message = new Message(Encoding.UTF8.GetBytes(messageJson));")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("await deviceClient.SendEventAsync(message);")
dte.ActiveDocument.Selection.NewLine()

