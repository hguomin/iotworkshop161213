/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("var deviceSchema = DeviceSchemaHelper.BuildDeviceStructure(deviceId);")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("var message = JsonConvert.SerializeObject(deviceSchema);")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("await SendMessageAsync(message, deviceClient);")
dte.ActiveDocument.Selection.NewLine()
