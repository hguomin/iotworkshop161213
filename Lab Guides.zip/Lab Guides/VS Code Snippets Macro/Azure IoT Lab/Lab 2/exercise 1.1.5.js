/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("var authMethod = new DeviceAuthenticationWithRegistrySymmetricKey(_deviceId, _devicePrimaryKey);")
dte.ActiveDocument.Selection.NewLine()