/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("_sendDeviceClient = DeviceClient.CreateFromConnectionString(deviceConnectionString, TransportType.Amqp);")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("_receiveDeviceClient = DeviceClient.CreateFromConnectionString(deviceConnectionString, TransportType.Amqp);")
dte.ActiveDocument.Selection.NewLine()