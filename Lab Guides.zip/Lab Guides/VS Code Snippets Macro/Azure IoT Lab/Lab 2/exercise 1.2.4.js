/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("// must be DeviceInfo or will not work, checked for in event webjob")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("device.Add(DeviceModelConstants.OBJECT_TYPE, \"DeviceInfo\");")
dte.ActiveDocument.Selection.NewLine()
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("// must be 1.0 or will not work, checked for in event webjob")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("device.Add(DeviceModelConstants.VERSION, \"1.0\");")
dte.ActiveDocument.Selection.NewLine()
Macro.InsertText("device.Add(DeviceModelConstants.IS_SIMULATED_DEVICE, \"false\");")
dte.ActiveDocument.Selection.NewLine()
