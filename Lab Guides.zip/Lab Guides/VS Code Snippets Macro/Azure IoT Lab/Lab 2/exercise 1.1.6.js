/// <reference path="C:\Users\guhuang\AppData\Local\Microsoft\VisualStudio\14.0\Macros\dte.js" />

Macro.InsertText("var deviceConnectionString = Microsoft.Azure.Devices.Client.IotHubConnectionStringBuilder.Create(_deviceHostName, authMethod).ToString();")
dte.ActiveDocument.Selection.NewLine()