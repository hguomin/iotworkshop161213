﻿using System;
using System.Collections.Generic;
using MSIOT_Hub_sample_device.Constants;
using Newtonsoft.Json.Linq;

namespace MSIOT_Hub_sample_device.Helpers
{
    /// <summary>
    /// Helper class to encapsulate interactions with the device schema.
    /// 
    /// Elsewhere in the app we try to always deal with this flexible schema as dynamic,
    /// but here we take a dependency on Json.Net where necessary to populate the objects 
    /// behind the schema.
    /// </summary>
    public static class DeviceSchemaHelper
    {
        /// <summary>
        /// Build a valid device representation in the dynamic format used throughout the app.
        /// </summary>
        /// <param name="deviceId"></param>
        /// <param name="isSimulated"></param>
        /// <returns></returns>
        public static dynamic BuildDeviceStructure(string deviceId)
        {
            
            JObject device = new JObject();

            // See exercise 1.2.4 for code detail
            // ** Paste code snippet here **


            // See exercise 1.2.5 for code details
            // ** Paste code snippet here **


            // See exercise 1.2.6 for code details
            // ** Paste code snippet here **


            return device;
        }
    }
}
